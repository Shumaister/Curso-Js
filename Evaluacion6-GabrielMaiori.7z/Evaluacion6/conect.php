
<?php
@$conexion=mysqli_connect('localhost', 'root', '', 'personas')
or exit("No se pudo seleccionar la base de datos");
?>






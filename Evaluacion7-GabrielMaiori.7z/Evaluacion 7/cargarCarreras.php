<?php   
    echo json_encode(array('Ingenieria en Sistemas de Informacion', 'Ingenieria Mecanica', 'Ingenieria Civil', 'Ingenieria Electronica')); exit;
?>